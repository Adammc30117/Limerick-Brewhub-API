package com.example.assignment_three_starter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentOneStarterApplicationTests {

    @Test
    void contextLoads() {
    }

}
