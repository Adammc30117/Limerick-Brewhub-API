package src.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import src.application.model.Review;
import src.application.service.ReviewService;
import java.util.Map;

@RestController
@RequestMapping("/api/reviews")
@Tag(name = "Review API", description = "Endpoints for submitting and updating beer reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    /**
     * Submits a new review for a beer.
     *
     * @param request JSON payload containing userId, beerId, rating, and comment.
     * @return The submitted review or an error message.
     */
    @Operation(summary = "Submit a new review", description = "Allows a user to submit a review for a beer.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Review submitted successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload"),
            @ApiResponse(responseCode = "404", description = "User or beer not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @PostMapping
    public ResponseEntity<?> submitReview(@RequestBody Map<String, Object> request) {
        try {
            Long userId = Long.valueOf(request.get("userId").toString());
            Long beerId = Long.valueOf(request.get("beerId").toString());
            int rating = Integer.parseInt(request.get("rating").toString());
            String comment = request.get("comment").toString();

            if (rating < 1 || rating > 5) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Rating must be between 1 and 5.");
            }

            Review review = reviewService.submitReview(userId, beerId, rating, comment);
            return ResponseEntity.ok(review);

        } catch (RuntimeException e) {
            if (e.getMessage().contains("User not found") || e.getMessage().contains("Beer not found")) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
            }
            return ResponseEntity.internalServerError().body("Error submitting review: " + e.getMessage());
        }
    }

    /**
     * Updates an existing review.
     *
     * @param reviewId The ID of the review to update.
     * @param request JSON payload containing new rating and comment.
     * @return The updated review or an error message.
     */
    @Operation(summary = "Update an existing review", description = "Allows modification of an existing beer review.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Review updated successfully"),
            @ApiResponse(responseCode = "404", description = "Review not found"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    @PutMapping("/{reviewId}")
    public ResponseEntity<?> updateReview(@PathVariable Long reviewId, @RequestBody Map<String, Object> request) {
        try {
            int newRating = Integer.parseInt(request.get("rating").toString());
            String newComment = request.get("comment").toString();

            if (newRating < 1 || newRating > 5) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Rating must be between 1 and 5.");
            }

            Review updatedReview = reviewService.updateReview(reviewId, newRating, newComment);
            return ResponseEntity.ok(updatedReview);

        } catch (RuntimeException e) {
            if (e.getMessage().contains("Review not found")) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
            }
            return ResponseEntity.internalServerError().body("Error updating review: " + e.getMessage());
        }
    }

}
