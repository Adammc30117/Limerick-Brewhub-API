package src.application.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import src.application.model.User;
import src.application.repository.CustomerRepository;
import java.util.List;

/**
 * Service for hashing and storing plain-text passwords for existing customer accounts.
 *
 * <p>This service retrieves all customers from the database, checks if their passwords
 * are already hashed, and if not, hashes them using a `PasswordEncoder` and updates
 * the database with the hashed passwords.</p>
 *
 * <p>Intended to be used for one-time operations on existing customer data to improve
 * security by hashing any remaining plain-text passwords.</p>
 */
@Service
public class PasswordHashingService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional
    public void hashExistingPasswords() {
        List<User> users = customerRepository.findAll();

        for (User user : users) {
            String plainTextPassword = user.getPassword();
            if (!plainTextPassword.startsWith("$2a$")) { // Check if it's already hashed
                String hashedPassword = passwordEncoder.encode(plainTextPassword);
                user.setPassword(hashedPassword);
                customerRepository.save(user);
            }
        }
    }
}

