package src.application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import src.application.model.RefreshToken;
import src.application.model.User;
import src.application.repository.RefreshTokenRepository;
import src.application.repository.CustomerRepository;
import java.time.Instant;
import java.util.UUID;

@Service
public class RefreshTokenService {

    @Autowired
    private RefreshTokenRepository refreshTokenRepository;

    @Autowired
    private CustomerRepository customerRepository;

    private static final long REFRESH_TOKEN_DURATION = 7 * 24 * 60 * 60; //7 days in seconds

    public String createRefreshToken(String email) {
        User user = customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        String token = UUID.randomUUID().toString();
        Instant expiryDate = Instant.now().plusSeconds(REFRESH_TOKEN_DURATION);

        RefreshToken refreshToken = new RefreshToken(token, expiryDate, user);
        refreshTokenRepository.save(refreshToken);

        return token;
    }

    public boolean isValidRefreshToken(String token) {
        return refreshTokenRepository.findByToken(token)
                //ensure token is still valid
                .filter(rt -> rt.getExpiryDate().isAfter(Instant.now()))
                .isPresent();
    }

    public String getUsernameFromToken(String token) {
        return refreshTokenRepository.findByToken(token)
                .map(rt -> rt.getCustomer().getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid refresh token"));
    }

    @Transactional
    public void revokeAllTokensForUser(String email) {
        User user = customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        refreshTokenRepository.deleteByCustomer(user);
    }

}
