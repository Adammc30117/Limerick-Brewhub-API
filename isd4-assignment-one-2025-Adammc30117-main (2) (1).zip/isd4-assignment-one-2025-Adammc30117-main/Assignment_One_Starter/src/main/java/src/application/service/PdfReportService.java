package src.application.service;

import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.springframework.stereotype.Service;
import src.application.dto.BreweryReportDTO;
import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Service responsible for generating structured PDF reports.
 */
@Service
public class PdfReportService {

    /**
     * Generates a PDF report for a specific brewery.
     *
     * @param breweryReport The brewery report data.
     * @return A byte array representing the generated PDF file.
     */
    public byte[] generateBreweryReport(BreweryReportDTO breweryReport) {
        try (PDDocument document = new PDDocument(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {

                float yPosition = 750; // Start position at the top of the page

                // Title
                addTitle(contentStream, "BREWERY REPORT", yPosition);
                yPosition -= 40;

                // Brewery Details
                addSectionTitle(contentStream, "Brewery Details:", yPosition);
                yPosition -= 20;
                addText(contentStream, "Brewery: " + breweryReport.getName(), yPosition);
                yPosition -= 15;
                addText(contentStream, "Location: " + breweryReport.getLocation(), yPosition);
                yPosition -= 15;
                addText(contentStream, "Contact: " + breweryReport.getContact(), yPosition);
                yPosition -= 30;

                // Customer Review Stats
                addSectionTitle(contentStream, "Customer Review Statistics:", yPosition);
                yPosition -= 20;
                addText(contentStream, "Average Rating: " + breweryReport.getAverageRating(), yPosition);
                yPosition -= 15;
                addText(contentStream, "Total Reviews: " + breweryReport.getNumberOfReviews(), yPosition);
                yPosition -= 30;

                // Beers Brewed
                addSectionTitle(contentStream, "Beers Brewed:", yPosition);
                yPosition -= 20;
                if (breweryReport.getBeers().isEmpty()) {
                    addText(contentStream, "No reviewed beers available.", yPosition);
                } else {
                    for (BreweryReportDTO.BeerInfo beer : breweryReport.getBeers()) {
                        addText(contentStream, "- " + beer.getBeerName() + " (" + beer.getStyle() + ", " + beer.getAbv() + "% ABV)", yPosition);
                        yPosition -= 15;
                    }
                }

            }

            document.save(outputStream);
            return outputStream.toByteArray();

        } catch (IOException e) {
            throw new RuntimeException("Error generating PDF", e);
        }
    }

    /**
     * Generates a PDF report for Beer & Brewery Analytics.
     *
     * @param topBeers       List of top-rated beers.
     * @param topBreweries   List of most engaged breweries.
     * @param seasonalTrends List of seasonal review trends.
     * @return A byte array representing the generated PDF file.
     */
    /**
     * Generates a PDF report for Beer & Brewery Analytics.
     *
     * @param topBeers       List of top-rated beers.
     * @param topBreweries   List of most engaged breweries.
     * @param seasonalTrends List of seasonal review trends.
     * @return A byte array representing the generated PDF file.
     */
    public byte[] generateAnalyticsReport(List<Map<String, Object>> topBeers,
                                          List<Map<String, Object>> topBreweries,
                                          List<Map<String, Object>> seasonalTrends) {
        try (PDDocument document = new PDDocument(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.OVERWRITE, true, true);

            float yPosition = 750;
            final float MARGIN = 50;
            final float PAGE_BOTTOM = MARGIN;

            // Title
            addTitle(contentStream, "Beer & Brewery Analytics Report", yPosition);
            yPosition -= 40;

            // Top-Rated Beers
            addSectionTitle(contentStream, "Top-Rated Beers(/5 stars):", yPosition);
            yPosition -= 20;

            int rank = 1; // Initialize ranking number
            for (Map<String, Object> beer : topBeers) {
                if (yPosition < PAGE_BOTTOM) {
                    contentStream = addNewPage(document, contentStream);
                    yPosition = 750;
                }
                addText(contentStream, rank + ". " + beer.get("name") + " (" + beer.get("avgRating") + " stars) - " + beer.get("brewery"), yPosition);
                yPosition -= 15;
                rank++; // Increment ranking number
            }
            yPosition -= 30;

// Most Engaged Breweries
            addSectionTitle(contentStream, "Most Engaged Breweries:", yPosition);
            yPosition -= 20;

            int breweryRank = 1; // Initialize ranking number
            for (Map<String, Object> brewery : topBreweries) {
                if (yPosition < PAGE_BOTTOM) {
                    contentStream = addNewPage(document, contentStream);
                    yPosition = 750;
                }

                // Add ranked brewery title
                addText(contentStream, breweryRank + ". " + brewery.get("brewery") + " (" + brewery.get("reviewCount") + " reviews)", yPosition);
                yPosition -= 15;

                // Include Country
                addText(contentStream, "   Country: " + brewery.get("country"), yPosition);
                yPosition -= 15;

                // Include Most Reviewed Style
                addText(contentStream, "   Most Reviewed Style: " + brewery.get("mostReviewedStyle"), yPosition);
                yPosition -= 20;

                breweryRank++; // Increment ranking number
            }


            // Force a new page before starting "Seasonal Review Trends"
            contentStream = addNewPage(document, contentStream);
            yPosition = 750; // Reset yPosition for the new page

            // Seasonal Trends
            addSectionTitle(contentStream, "Seasonal Review Trends:", yPosition);
            yPosition -= 30; // Space before first year's data

            boolean isFirstYear = true; // Flag to check the first year

            for (Map.Entry<Integer, List<Map<String, Object>>> yearlyData : groupSeasonsByYear(seasonalTrends).entrySet()) {
                int trendYear = yearlyData.getKey();
                List<Map<String, Object>> seasons = yearlyData.getValue();

                if (!isFirstYear) {
                    // **Start a new page for each year AFTER the first one**
                    contentStream = addNewPage(document, contentStream);
                    yPosition = 750;
                }

                // Add Year Title
                addTitle(contentStream, "Year: " + trendYear, yPosition);
                yPosition -= 50;

                // Process each season
                for (Map<String, Object> seasonData : seasons) {
                    addSectionTitle(contentStream, seasonData.get("season") + ":", yPosition);
                    yPosition -= 20;

                    addText(contentStream, "Reviews: " + seasonData.get("reviewCount"), yPosition);
                    yPosition -= 15;

                    if (seasonData.get("highestRatedBeer") != null) {
                        addText(contentStream, "Highest Rated: " + seasonData.get("highestRatedBeer") +
                                " (" + seasonData.get("highestRatedBeerBrewery") + ") - " + seasonData.get("highestRatedBeerRating") + " stars", yPosition);
                        yPosition -= 15;
                    }

                    if (seasonData.get("mostReviewedBeer") != null) {
                        addText(contentStream, "Most Reviewed: " + seasonData.get("mostReviewedBeer") +
                                " (" + seasonData.get("mostReviewedBeerCount") + " reviews)", yPosition);
                        yPosition -= 15;
                    }

                    if (seasonData.get("mostReviewedStyle") != null) {
                        addText(contentStream, "Most Reviewed Style: " + seasonData.get("mostReviewedStyle"), yPosition);
                        yPosition -= 20;
                    }
                }

                // ** Generate and Insert the Graph at the Bottom **
                yPosition = 120; // Reserve space for the graph at the bottom
                byte[] chartImage = generateSeasonalTrendChart(trendYear, seasons);
                addImageToPDF(contentStream, document, chartImage, 50, yPosition, 500, 200);

                isFirstYear = false; // After first year, enable page breaks
            }

            contentStream.close(); // Ensure content stream is properly closed
            document.save(outputStream);
            document.close(); // Close document to free memory
            return outputStream.toByteArray();


        } catch (IOException e) {
            throw new RuntimeException("Error generating analytics PDF", e);
        }
    }

    /**
     * Adds a new page and returns a new content stream.
     */
    private PDPageContentStream addNewPage(PDDocument document, PDPageContentStream oldContentStream) throws IOException {
        if (oldContentStream != null) {
            oldContentStream.close();
        }

        PDPage newPage = new PDPage(PDRectangle.A4);
        document.addPage(newPage);

        PDPageContentStream newContentStream = new PDPageContentStream(document, newPage, PDPageContentStream.AppendMode.OVERWRITE, true, true);
        newContentStream.setFont(PDType1Font.HELVETICA, 12);

        return newContentStream;
    }

    // Helper method to add centered titles
    private void addTitle(PDPageContentStream contentStream, String text, float yPosition) throws IOException {
        if (contentStream == null) return;
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 18);

        // Calculate text width for centering
        float titleWidth = PDType1Font.HELVETICA_BOLD.getStringWidth(text) / 1000 * 18; // Scale by font size
        float pageWidth = PDRectangle.A4.getWidth();
        float centerX = (pageWidth - titleWidth) / 2; // Calculate center position

        contentStream.beginText();
        contentStream.newLineAtOffset(centerX, yPosition);
        contentStream.showText(text);
        contentStream.endText();
    }


    // Helper method to add section titles
    private void addSectionTitle(PDPageContentStream contentStream, String text, float yPosition) throws IOException {
        if (contentStream == null) return;
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 14);
        contentStream.beginText();
        contentStream.newLineAtOffset(50, yPosition);
        contentStream.showText(text);
        contentStream.endText();
    }

    // Helper method to add text content
    private void addText(PDPageContentStream contentStream, String text, float yPosition) throws IOException {
        if (contentStream == null) return;
        contentStream.setFont(PDType1Font.HELVETICA, 12);
        contentStream.beginText();
        contentStream.newLineAtOffset(50, yPosition);
        contentStream.showText(text);
        contentStream.endText();
    }

    private Map<Integer, List<Map<String, Object>>> groupSeasonsByYear(List<Map<String, Object>> trends) {
        Map<Integer, List<Map<String, Object>>> groupedData = new LinkedHashMap<>();
        for (Map<String, Object> trend : trends) {
            int year = (int) trend.get("year");
            groupedData.putIfAbsent(year, new ArrayList<>());
            groupedData.get(year).add(trend);
        }
        return groupedData;
    }
    private byte[] generateSeasonalTrendChart(int year, List<Map<String, Object>> seasons) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        int maxReviewCount = 0; // Find max review count for scaling
        for (Map<String, Object> seasonData : seasons) {
            int reviewCount = (int) seasonData.get("reviewCount");
            dataset.addValue(reviewCount, "Reviews", (String) seasonData.get("season"));
            if (reviewCount > maxReviewCount) {
                maxReviewCount = reviewCount;
            }
        }

        JFreeChart barChart = ChartFactory.createBarChart(
                "Seasonal Review Trends - " + year,
                "Season", "Reviews", dataset, PlotOrientation.VERTICAL, false, true, false);

        CategoryPlot plot = (CategoryPlot) barChart.getPlot();
        //plot.setBackgroundPaint(Color.WHITE);
        plot.setBackgroundPaint(new Color(220, 235, 245)); // Light gray background
        plot.setDomainGridlinePaint(Color.BLACK); // Black gridlines on x-axis
        plot.setRangeGridlinePaint(Color.BLACK); // Black gridlines on y-axis

        NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();

        // **Dynamic Scaling of Y-Axis**
        yAxis.setRange(0, maxReviewCount + 2);
        yAxis.setTickUnit(new NumberTickUnit(Math.max(1, maxReviewCount / 5))); // Ensure readable increments

        // **Rotate X-Axis Labels for Better Readability**
        CategoryAxis xAxis = plot.getDomainAxis();
        xAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45); // Rotate labels 45 degrees

        // **Increase Chart Size for Better Display**
        int chartWidth = 800;
        int chartHeight = 400;

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            ChartUtils.writeChartAsPNG(baos, barChart, chartWidth, chartHeight);
            return baos.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException("Error generating chart image", e);
        }
    }

    private void addImageToPDF(PDPageContentStream contentStream, PDDocument document, byte[] imageBytes, float x, float y, float width, float height) throws IOException {
        PDImageXObject pdImage = PDImageXObject.createFromByteArray(document, imageBytes, "chart.png");
        contentStream.drawImage(pdImage, x, y, width, height);
    }
}