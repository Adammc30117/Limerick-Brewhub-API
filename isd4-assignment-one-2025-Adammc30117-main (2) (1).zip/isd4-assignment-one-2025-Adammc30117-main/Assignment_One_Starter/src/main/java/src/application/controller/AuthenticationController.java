package src.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;
import src.application.authentication.AuthenticationRequest;
import src.application.authentication.AuthenticationResponse;
import src.application.security.JwtUtil;
import src.application.service.RefreshTokenService;
import src.application.service.TokenBlacklistService;

import java.util.Map;

@RestController
@Tag(name = "Authentication API", description = "Endpoints for authentication, token refresh, and logout")
public class AuthenticationController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtTokenUtil;
    private final UserDetailsService userDetailsService;

    @Autowired
    private RefreshTokenService refreshTokenService;

    @Autowired
    private TokenBlacklistService tokenBlacklistService;

    public AuthenticationController(
            AuthenticationManager authenticationManager,
            JwtUtil jwtTokenUtil,
            UserDetailsService userDetailsService) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenUtil = jwtTokenUtil;
        this.userDetailsService = userDetailsService;
    }

    /**
     * Authenticates a user and generates an access token and refresh token.
     *
     * @param authenticationRequest The user's login credentials.
     * @return An authentication response containing an access token and refresh token.
     */
    @Operation(summary = "User Authentication", description = "Authenticates a user and returns an access and refresh token.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Authentication successful"),
            @ApiResponse(responseCode = "401", description = "Incorrect email or password"),
            @ApiResponse(responseCode = "400", description = "Bad request - missing parameters")
    })
    @PostMapping("/authenticate")
    public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) {
        if (authenticationRequest.getEmail() == null || authenticationRequest.getPassword() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email and password are required.");
        }

        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authenticationRequest.getEmail(), authenticationRequest.getPassword()));
        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect email or password");
        }

        final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getEmail());

        // Blacklist previous tokens
        tokenBlacklistService.blacklistPreviousTokens(userDetails.getUsername());

        // Generate new tokens
        String accessToken = jwtTokenUtil.generateToken(userDetails.getUsername());
        tokenBlacklistService.storeToken(userDetails.getUsername(), accessToken);
        String refreshToken = refreshTokenService.createRefreshToken(userDetails.getUsername());

        return ResponseEntity.ok(new AuthenticationResponse(accessToken, refreshToken));
    }

    /**
     * Refreshes an access token using a valid refresh token.
     *
     * @param request A map containing the refresh token.
     * @return A new access token.
     */
    @Operation(summary = "Refresh Access Token", description = "Generates a new access token using a valid refresh token.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "New access token generated"),
            @ApiResponse(responseCode = "401", description = "Invalid or expired refresh token"),
            @ApiResponse(responseCode = "400", description = "Bad request - missing refresh token")
    })
    @PostMapping("/refresh-token")
    public ResponseEntity<?> refreshAccessToken(@RequestBody Map<String, String> request) {
        String refreshToken = request.get("refreshToken");

        if (refreshToken == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Refresh token is required.");
        }

        if (!refreshTokenService.isValidRefreshToken(refreshToken)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid or expired refresh token");
        }

        String username = refreshTokenService.getUsernameFromToken(refreshToken);
        String newAccessToken = jwtTokenUtil.generateToken(username);

        return ResponseEntity.ok(Map.of("accessToken", newAccessToken));
    }

    /**
     * Logs out a user by revoking the refresh token and blacklisting the access token.
     *
     * @param accessToken The access token in the Authorization header.
     * @param request A map containing the refresh token.
     * @return A success message upon logout.
     */
    @Operation(summary = "Logout", description = "Logs out a user by revoking the refresh token and blacklisting the access token.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Logged out successfully"),
            @ApiResponse(responseCode = "400", description = "Bad request - missing Authorization header or refresh token")
    })
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader(value = "Authorization", required = false) String accessToken,
                                    @RequestBody Map<String, String> request) {
        String refreshToken = request.get("refreshToken");

        if (accessToken == null || refreshToken == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Authorization header and refresh token are required for logout.");
        }

        String username = jwtTokenUtil.extractUsername(accessToken.substring(7));
        refreshTokenService.revokeAllTokensForUser(username);

        if (accessToken.startsWith("Bearer ")) {
            tokenBlacklistService.blacklistToken(accessToken.substring(7));
        }

        return ResponseEntity.ok("Logged out successfully from all sessions.");
    }
}
