package src.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import src.application.service.AnalyticsService;
import src.application.service.QRCodeService;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/analytics")
@Tag(name = "Analytics API", description = "Endpoints for beer analytics and reports")
public class AnalyticsController {

    private static final Logger logger = LoggerFactory.getLogger(AnalyticsController.class);

    private final AnalyticsService analyticsService;
    private final QRCodeService qrCodeService;

    public AnalyticsController(AnalyticsService analyticsService, QRCodeService qrCodeService) {
        this.analyticsService = analyticsService;
        this.qrCodeService = qrCodeService;
    }

    /**
     * Generates a QR code containing analytics data.
     *
     * @return A PNG image of the QR code or an error response.
     */
    @Operation(summary = "Generate analytics QR code", description = "Returns a QR code image with analytics data.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "QR code generated successfully"),
            @ApiResponse(responseCode = "204", description = "No analytics data available"),
            @ApiResponse(responseCode = "400", description = "Invalid input provided")
    })
    @GetMapping(value = "/qr-code", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<byte[]> getAnalyticsQRCode() {
        try {
            byte[] qrCodeBytes = qrCodeService.generateAnalyticsQRCode();

            if (qrCodeBytes == null || qrCodeBytes.length == 0) {
                logger.warn("QR Code generation failed: No data available");
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_PNG)
                    .body(qrCodeBytes);
        } catch (IllegalArgumentException e) {
            logger.error("Invalid input for QR Code generation", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        } catch (Exception e) {
            logger.error("Unexpected error generating QR code", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    /**
     * Get top-rated beers based on review scores.
     *
     * @return A list of top-rated beers or 204 No Content if no data exists.
     */
    @Operation(summary = "Get top-rated beers", description = "Fetches the top-rated beers based on reviews.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Top-rated beers retrieved successfully"),
            @ApiResponse(responseCode = "204", description = "No data available")
    })
    @GetMapping(value = "/top-beers", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Map<String, Object>>> getTopRatedBeers() {
        List<Map<String, Object>> topBeers = analyticsService.getTopRatedBeers();

        if (topBeers == null || topBeers.isEmpty()) {
            logger.info("No top-rated beers available.");
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(topBeers);
    }

    /**
     * Get breweries with the highest engagement (most reviewed beers).
     *
     * @return A list of breweries or 204 No Content if no data exists.
     */
    @Operation(summary = "Get top-engaged breweries", description = "Fetches the breweries with the highest engagement.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Top breweries retrieved successfully"),
            @ApiResponse(responseCode = "204", description = "No data available")
    })
    @GetMapping(value = "/top-breweries", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Map<String, Object>>> getTopEngagedBreweries() {
        List<Map<String, Object>> topBreweries = analyticsService.getTopEngagedBreweries();

        if (topBreweries == null || topBreweries.isEmpty()) {
            logger.info("No top breweries available.");
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(topBreweries);
    }

    /**
     * Get monthly review trends.
     *
     * @return A list of monthly review trends or 204 No Content if no data exists.
     */
    @Operation(summary = "Get review trends", description = "Retrieves seasonal review trends for beer ratings.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Review trends retrieved successfully"),
            @ApiResponse(responseCode = "204", description = "No data available")
    })
    @GetMapping(value = "/review-trends", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Map<String, Object>>> getReviewTrends() {
        List<Map<String, Object>> reviewTrends = analyticsService.getSeasonalReviewTrends();

        if (reviewTrends == null || reviewTrends.isEmpty()) {
            logger.info("No review trends available.");
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(reviewTrends);
    }

    /**
     * Generate an analytics report as a PDF file.
     *
     * @return A PDF file or an error response.
     */
    @Operation(summary = "Generate analytics report", description = "Creates a detailed analytics report as a PDF.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Analytics report generated successfully"),
            @ApiResponse(responseCode = "204", description = "No analytics data available"),
            @ApiResponse(responseCode = "400", description = "Invalid request parameters"),
            @ApiResponse(responseCode = "500", description = "Unexpected server error")
    })
    @GetMapping(value = "/report", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> getAnalyticsReport() {
        try {
            byte[] pdfBytes = analyticsService.generateAnalyticsReport();

            if (pdfBytes == null || pdfBytes.length == 0) {
                logger.warn("Analytics report request failed: No data available.");
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=analytics_report.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfBytes);
        } catch (IllegalArgumentException e) {
            logger.error("Invalid request parameters for analytics report", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        } catch (Exception e) {
            logger.error("Unexpected error generating analytics report", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
