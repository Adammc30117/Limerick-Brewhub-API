package src.application.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Service
public class QRCodeService {

    private final AnalyticsService analyticsService;
    private static final String GITHUB_TOKEN = "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";
    private static final String REPO_OWNER = "Adammc30117";
    private static final String REPO_NAME = "beer-analytics-reports";
    private static final String PDF_FILENAME = "analytics_report.pdf";

    RestTemplate restTemplate = new RestTemplate();


    public QRCodeService(AnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

    public byte[] generateAnalyticsQRCode() {
        try {
            // **1. Generate PDF**
            byte[] pdfBytes = analyticsService.generateAnalyticsReport();

            // **2. Upload PDF to GitHub**
            String pdfUrl = uploadPDFToGitHub(pdfBytes);

            // **3. Generate QR Code for the PDF URL**
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(pdfUrl, BarcodeFormat.QR_CODE, 300, 300);

            ByteArrayOutputStream pngOutputStream = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bitMatrix, "PNG", pngOutputStream);

            return pngOutputStream.toByteArray();

        } catch (WriterException | IOException e) {
            throw new RuntimeException("Error generating QR Code", e);
        }
    }

    private String uploadPDFToGitHub(byte[] pdfBytes) {
        try {
            // **GitHub File Check URL**
            String checkUrl = String.format("https://api.github.com/repos/%s/%s/contents/%s",
                    REPO_OWNER, REPO_NAME, PDF_FILENAME);

            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(GITHUB_TOKEN);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> checkResponse = restTemplate.exchange(checkUrl, HttpMethod.GET, new HttpEntity<>(headers), String.class);

            String sha = null; // GitHub requires this for updating an existing file

            if (checkResponse.getStatusCode() == HttpStatus.OK) {
                // Extract SHA from response (needed for updating the file)
                Map<String, Object> responseBody = new ObjectMapper().readValue(checkResponse.getBody(), Map.class);
                sha = (String) responseBody.get("sha");
            }

            // **Convert PDF bytes to Base64**
            String base64Pdf = Base64.getEncoder().encodeToString(pdfBytes);

            // **Prepare JSON payload**
            Map<String, Object> payload = new HashMap<>();
            payload.put("message", "Updating analytics report");
            payload.put("content", base64Pdf);
            if (sha != null) {
                payload.put("sha", sha); // Required if updating an existing file
            }

            // Convert payload to JSON
            String jsonPayload = new ObjectMapper().writeValueAsString(payload);

            // **GitHub Upload URL**
            String uploadUrl = String.format("https://api.github.com/repos/%s/%s/contents/%s",
                    REPO_OWNER, REPO_NAME, PDF_FILENAME);

            HttpHeaders uploadHeaders = new HttpHeaders();
            uploadHeaders.setBearerAuth(GITHUB_TOKEN);
            uploadHeaders.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> requestEntity = new HttpEntity<>(jsonPayload, uploadHeaders);
            ResponseEntity<String> uploadResponse = restTemplate.exchange(uploadUrl, HttpMethod.PUT, requestEntity, String.class);

            if (uploadResponse.getStatusCode() == HttpStatus.OK || uploadResponse.getStatusCode() == HttpStatus.CREATED) {
                return "https://raw.githubusercontent.com/" + REPO_OWNER + "/" + REPO_NAME + "/main/" + PDF_FILENAME;
            } else {
                throw new RuntimeException("GitHub upload failed: " + uploadResponse.getBody());
            }

        } catch (Exception e) {
            throw new RuntimeException("Error uploading PDF to GitHub", e);
        }
    }

}
