package src.application.service;

import org.springframework.stereotype.Service;
import src.application.dto.BreweryReportDTO;
import src.application.model.Beer;
import src.application.model.Brewery;
import src.application.model.Review;
import src.application.repository.BreweryRepository;
import src.application.repository.ReviewRepository;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * BreweryService.java
 *
 * This service handles retrieving brewery details and generating reports.
 * It fetches brewery data, filters beers that have received reviews, and calculates customer review statistics.
 *
 * Methods:
 * - getBreweryReport(Long breweryId): Generates a structured report for a given brewery.
 */

@Service
public class BreweryService {
    private final BreweryRepository breweryRepository;
    private final ReviewRepository reviewRepository;

    /**
     * Constructor for BreweryService.
     *
     * @param breweryRepository Repository for Brewery data.
     * @param reviewRepository Repository for Review data.
     */
    public BreweryService(BreweryRepository breweryRepository, ReviewRepository reviewRepository) {
        this.breweryRepository = breweryRepository;
        this.reviewRepository = reviewRepository;
    }

    /**
     * Generates a Brewery Report containing details, reviewed beers, and customer review statistics.
     *
     * @param breweryId The ID of the brewery.
     * @return BreweryReportDTO containing brewery details and reviewed beers.
     * @throws RuntimeException if the brewery is not found.
     */
    public BreweryReportDTO getBreweryReport(Long breweryId) {
        // Fetch brewery by ID
        Optional<Brewery> breweryOpt = breweryRepository.findById(breweryId);
        if (breweryOpt.isEmpty()) {
            throw new RuntimeException("Brewery not found");
        }
        Brewery brewery = breweryOpt.get();

        // Get all beers brewed by this brewery
        List<Beer> brewedBeers = brewery.getBeers();

        // Filter beers to only include those that have received at least one review
        List<BreweryReportDTO.BeerInfo> beers = brewedBeers.stream()
                .filter(beer -> !beer.getReviews().isEmpty()) // Exclude beers with no reviews
                .map(beer -> new BreweryReportDTO.BeerInfo(
                        beer.getName(),
                        beer.getStyle().getStyle_name(),
                        beer.getAbv()))
                .distinct() // Remove duplicate beers
                .collect(Collectors.toList());

        // Get all reviews for beers brewed by this brewery
        List<Review> reviews = reviewRepository.findByBeer_Brewery_Id(breweryId);

        // Calculate average rating from these reviews, rounded to two decimal places
        double avgRating = reviews.isEmpty() ? 0.0 :
                Math.round(reviews.stream().mapToInt(Review::getRating).average().orElse(0.0) * 100.0) / 100.0;

        // Construct and return the Brewery Report DTO
        return new BreweryReportDTO(
                brewery.getName(),
                brewery.getAddress(),
                brewery.getContact(),
                brewery.getLatitude(),
                brewery.getLongitude(),
                avgRating,
                reviews.size(),
                beers);
    }
}
