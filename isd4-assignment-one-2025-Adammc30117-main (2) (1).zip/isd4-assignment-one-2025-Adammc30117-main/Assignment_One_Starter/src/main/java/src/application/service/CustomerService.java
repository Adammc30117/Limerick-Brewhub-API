package src.application.service;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import src.application.dto.CustomerSummaryDTO;
import src.application.model.*;
import src.application.repository.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Service class responsible for handling customer-related operations,
 * including fetching customer summaries and converting them to various formats.
 */
@Service
public class CustomerService implements UserDetailsService {
    private final CustomerRepository customerRepository;
    private final ReviewRepository reviewRepository;
    private final BeerRepository beerRepository;
    private final BreweryRepository breweryRepository;
    private final PasswordEncoder passwordEncoder;




    /**
     * Constructor for CustomerService, injecting necessary repositories.
     *
     * @param customerRepository Repository for customer data.
     * @param reviewRepository Repository for review data.
     * @param beerRepository Repository for beer data.
     * @param breweryRepository Repository for brewery data.
     */
    public CustomerService(CustomerRepository customerRepository, ReviewRepository reviewRepository,
                           BeerRepository beerRepository, BreweryRepository breweryRepository, PasswordEncoder passwordEncoder) {
        this.customerRepository = customerRepository;
        this.reviewRepository = reviewRepository;
        this.beerRepository = beerRepository;
        this.breweryRepository = breweryRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Retrieves a summary of a given customer, including their reviewed beers and associated breweries.
     *
     * @param customerId The ID of the customer to retrieve.
     * @return CustomerSummaryDTO containing customer details and reviews.
     * @throws RuntimeException if the customer is not found.
     */
    public CustomerSummaryDTO getCustomerSummary(Long customerId) {
        Optional<User> customer = customerRepository.findById(customerId);
        if (customer.isEmpty()) {
            throw new RuntimeException("Customer not found");
        }

        // Retrieve all reviews written by this customer
        List<Review> reviews = reviewRepository.findByUserId(customerId);

        // Map each review to a BeerReviewDTO containing details about the beer, brewery, and the review itself
        List<CustomerSummaryDTO.BeerReviewDTO> beerReviews = reviews.stream().map(review -> {
            Beer beer = review.getBeer();
            Brewery brewery = beer.getBrewery();
            return new CustomerSummaryDTO.BeerReviewDTO(
                    beer.getName(),
                    beer.getStyle().getStyle_name(),
                    beer.getAbv(),
                    beer.getCategory().getCat_name(),
                    brewery.getName(),
                    brewery.getCountry(),
                    brewery.getState(),
                    review.getRating(),
                    review.getComment(),
                    review.getReviewDate().toString()
            );
        }).collect(Collectors.toList());

        // Return the full customer summary including their name, email, and beer reviews
        return new CustomerSummaryDTO(
                customer.get().getFirstName() + " " + customer.get().getLastName(),
                customer.get().getEmail(),
                beerReviews);
    }

    /**
     * Converts a CustomerSummaryDTO into a TSV (Tab-Separated Values) format.
     *
     * @param summary The CustomerSummaryDTO to convert.
     * @return A TSV string representation of the summary.
     */
    public String convertToTSV(CustomerSummaryDTO summary) {
        StringBuilder sb = new StringBuilder();

        // Add headers for the TSV file
        sb.append("Customer Name\tCustomer Email\tBeer Name\tStyle\tABV\tCategory\tBrewery\tCountry\tState\tRating\tComment\tReview Date\n");

        // Iterate through each beer review and append it in TSV format
        for (CustomerSummaryDTO.BeerReviewDTO review : summary.getBeerReviews()) {
            // Remove newlines and extra spaces in comments to maintain proper TSV formatting
            String sanitizedComment = review.getComment()
                    .replace("\n", " ")
                    .replace("\r", " ")
                    .trim();

            sb.append(String.format("%s\t%s\t%s\t%s\t%.2f\t%s\t%s\t%s\t%s\t%d\t%s\t%s\n",
                    summary.getName(),
                    summary.getEmail(),
                    review.getBeerName(),
                    review.getStyle(),
                    review.getAbv(),
                    review.getCategory(),
                    review.getBreweryName(),
                    review.getCountry(),
                    review.getState(),
                    review.getRating(),
                    sanitizedComment,
                    review.getReviewDate()));
        }
        return sb.toString();
    }

    /*
   This method loads a user by their email, retrieves their roles from the database,
   converts them into authorities, and returns a UserDetails object with the user’s
   credentials and roles for Spring Security authentication.
    */

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = customerRepository.findByEmail(email) // 🔹 Now using `email`, not `username`
                .orElseThrow(() -> new UsernameNotFoundException("Customer not found with email: " + email));


        List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole()));

        return new org.springframework.security.core.userdetails.User(
                user.getEmail(), // Use email
                user.getPassword(),
                true, true, true, true,
                authorities
        );
    }



    /*
    This method converts a set of Role objects into a collection of GrantedAuthority
    objects prefixed with "ROLE_" for use in authorisation.
    */
    private Collection<? extends GrantedAuthority> getAuthorities(Set<Role> roles) {
        Set<GrantedAuthority> authorities = new HashSet();
        for (Role role : roles) {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role.name()));


        }
        return authorities;
    }

    public List<User> findAll() {
        return customerRepository.findAll();
    }

    public Optional<User> findById(Integer id) {
        return customerRepository.findById(Long.valueOf(id));
    }

    public User save(User entity) {
        entity.setPassword(passwordEncoder.encode(entity.getPassword())); // 🔹 Hash the password
        return customerRepository.save(entity);
    }

    public void deleteById(Integer id) {
        customerRepository.deleteById(Long.valueOf(id));
    }
}

