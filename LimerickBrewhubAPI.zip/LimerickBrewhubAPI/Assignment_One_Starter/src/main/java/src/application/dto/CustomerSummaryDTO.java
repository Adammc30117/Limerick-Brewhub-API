package src.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.List;

/**
 * DTO for summarizing customer beer review history.
 * Used to format the response data without exposing database entities.
 */
@JsonRootName(value = "customerSummary")
@JsonInclude(JsonInclude.Include.NON_NULL) // Excludes null fields from the response
public class CustomerSummaryDTO implements Serializable {

    @JsonProperty("name")
    private String name;

    @JsonProperty("email")
    private String email;

    @JsonProperty("beerReviews")
    private List<BeerReviewDTO> beerReviews;

    /**
     * Constructor for CustomerSummaryDTO.
     */
    public CustomerSummaryDTO(String name, String email, List<BeerReviewDTO> beerReviews) {
        this.name = name;
        this.email = email;
        this.beerReviews = beerReviews;
    }

    // Getters
    public String getName() { return name; }
    public String getEmail() { return email; }
    public List<BeerReviewDTO> getBeerReviews() { return beerReviews; }

    /**
     * Inner DTO for representing individual beer reviews.
     */
    public static class BeerReviewDTO {

        @JsonProperty("beerName")
        private String beerName;

        @JsonProperty("style")
        private String style;

        @JsonProperty("abv")
        private Double abv;

        @JsonProperty("category")
        private String category;

        @JsonProperty("breweryName")
        private String breweryName;

        @JsonProperty("country")
        private String country;

        @JsonProperty("state")
        private String state;

        @JsonProperty("rating")
        private int rating;

        @JsonProperty("comment")
        private String comment;

        @JsonProperty("reviewDate")
        private String reviewDate;

        /**
         * Constructor for BeerReviewDTO.
         */
        public BeerReviewDTO(String beerName, String style, Double abv, String category,
                             String breweryName, String country, String state, int rating,
                             String comment, String reviewDate) {
            this.beerName = beerName;
            this.style = style;
            this.abv = abv;
            this.category = category;
            this.breweryName = breweryName;
            this.country = country;
            this.state = state;
            this.rating = rating;
            this.comment = comment;
            this.reviewDate = reviewDate;
        }

        // Getters
        public String getBeerName() { return beerName; }
        public String getStyle() { return style; }
        public Double getAbv() { return abv; }
        public String getCategory() { return category; }
        public String getBreweryName() { return breweryName; }
        public String getCountry() { return country; }
        public String getState() { return state; }
        public int getRating() { return rating; }
        public String getComment() { return comment; }
        public String getReviewDate() { return reviewDate; }
    }
}
