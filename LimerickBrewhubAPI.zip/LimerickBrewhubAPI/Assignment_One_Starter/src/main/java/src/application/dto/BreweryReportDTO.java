package src.application.dto;

import java.util.List;

/**
 * DTO (Data Transfer Object) for brewery reports.
 *
 * This is used to structure the brewery report data before sending it to the client.
 * It helps keep the response clean and avoids exposing database models directly.
 */
public class BreweryReportDTO {
    private String name;
    private String location;
    private String contact;
    private Double latitude;
    private Double longitude;
    private double averageRating;
    private int numberOfReviews;
    private List<BeerInfo> beers;

    /**
     * Constructor for BreweryReportDTO.
     */
    public BreweryReportDTO(String name, String location, String contact, Double latitude, Double longitude,
                            double averageRating, int numberOfReviews, List<BeerInfo> beers) {
        this.name = name;
        this.location = location;
        this.contact = contact;
        this.latitude = latitude;
        this.longitude = longitude;
        this.averageRating = averageRating;
        this.numberOfReviews = numberOfReviews;
        this.beers = beers;
    }

    // Getters
    public String getName() { return name; }
    public String getLocation() { return location; }
    public String getContact() { return contact; }
    public Double getLatitude() { return latitude; }
    public Double getLongitude() { return longitude; }
    public double getAverageRating() { return averageRating; }
    public int getNumberOfReviews() { return numberOfReviews; }
    public List<BeerInfo> getBeers() { return beers; }

    /**
     * Represents information about a beer in the brewery report.
     */
    public static class BeerInfo {
        private String beerName;
        private String style;
        private Double abv;

        /**
         * Constructor for BeerInfo.
         */
        public BeerInfo(String beerName, String style, Double abv) {
            this.beerName = beerName;
            this.style = style;
            this.abv = abv;
        }

        // Getters
        public String getBeerName() { return beerName; }
        public String getStyle() { return style; }
        public Double getAbv() { return abv; }
    }
}
