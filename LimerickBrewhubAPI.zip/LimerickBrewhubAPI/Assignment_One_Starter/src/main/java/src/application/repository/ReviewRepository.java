package src.application.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import src.application.model.Review;

import java.util.List;

@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByBeerId(Long beerId); // Fetch all reviews (including pending)

    List<Review> findByUserId(Long id); // Fetch all user reviews

    List<Review> findByBeer_Brewery_Id(Long breweryId); // Fetch all reviews for a brewery

    int countByBeerId(Long beerId);


}
