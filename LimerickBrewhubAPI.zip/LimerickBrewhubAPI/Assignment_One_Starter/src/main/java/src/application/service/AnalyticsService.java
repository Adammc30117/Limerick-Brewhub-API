package src.application.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import src.application.model.Beer;
import src.application.model.Brewery;
import src.application.model.Review;
import src.application.repository.BeerRepository;
import src.application.repository.BreweryRepository;
import src.application.repository.ReviewRepository;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AnalyticsService {
    private final ReviewRepository reviewRepository;
    private final BeerRepository beerRepository;
    private final BreweryRepository breweryRepository;
    private final PdfReportService pdfReportService;

    public AnalyticsService(ReviewRepository reviewRepository, BeerRepository beerRepository,
                            BreweryRepository breweryRepository, PdfReportService pdfReportService) {
        this.reviewRepository = reviewRepository;
        this.beerRepository = beerRepository;
        this.breweryRepository = breweryRepository;
        this.pdfReportService = pdfReportService;
    }

    private static final String GITHUB_TOKEN = "REDACTED_FOR_SECURITY";

    private static final String REPO_OWNER = "Adammc30117";
    private static final String REPO_NAME = "beer-analytics-reports";
    private static final String FILE_PATH = "analytics_report.pdf";

    public String uploadPDFToGitHub(byte[] pdfBytes) {
        String apiUrl = "https://api.github.com/repos/" + REPO_OWNER + "/" + REPO_NAME + "/contents/" + FILE_PATH;

        // Convert PDF to Base64
        String base64Content = Base64.getEncoder().encodeToString(pdfBytes);

        // Prepare JSON payload
        Map<String, String> payload = Map.of(
                "message", "Upload latest analytics report",
                "content", base64Content
        );

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + GITHUB_TOKEN);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(payload, headers);
        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<Map> response = restTemplate.exchange(apiUrl, HttpMethod.PUT, requestEntity, Map.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            return "https://raw.githubusercontent.com/" + REPO_OWNER + "/" + REPO_NAME + "/main/" + FILE_PATH;
        } else {
            throw new RuntimeException("GitHub upload failed");
        }
    }

    /**
     * Fetches the top-rated beers based on average review ratings.
     */
    public List<Map<String, Object>> getTopRatedBeers() {
        List<Beer> beers = beerRepository.findAll();
        return beers.stream()
                .filter(beer -> beer.getAvgRating() != null)
                .sorted(Comparator.comparingDouble(Beer::getAvgRating).reversed())
                .limit(10)
                .map(beer -> {
                    Map<String, Object> result = new HashMap<>();
                    result.put("name", beer.getName());
                    result.put("avgRating", String.format("%.2f", beer.getAvgRating())); // Format to 2 decimal places
                    result.put("brewery", beer.getBrewery().getName());
                    return result;
                })
                .collect(Collectors.toList());
    }

    /**
     * Fetches breweries with the most customer engagement (most reviews).
     */
    public List<Map<String, Object>> getTopEngagedBreweries() {
        List<Brewery> breweries = breweryRepository.findAll();

        return breweries.stream()
                .map(brewery -> {
                    // Count reviews for all beers brewed by this brewery
                    int totalReviews = brewery.getBeers().stream()
                            .mapToInt(beer -> reviewRepository.countByBeerId(beer.getId()))
                            .sum();

                    // Determine the most reviewed style for the brewery
                    Map<String, Integer> styleReviewCounts = new HashMap<>();
                    for (Beer beer : brewery.getBeers()) {
                        if (beer.getStyle() != null) {
                            String styleName = beer.getStyle().getStyle_name();
                            int reviewCount = reviewRepository.countByBeerId(beer.getId());
                            styleReviewCounts.put(styleName, styleReviewCounts.getOrDefault(styleName, 0) + reviewCount);
                        }
                    }

                    // Get the most reviewed style
                    String mostReviewedStyle = styleReviewCounts.entrySet().stream()
                            .max(Map.Entry.comparingByValue())
                            .map(Map.Entry::getKey)
                            .orElse("Not Set");

                    // Only include breweries that have reviews
                    if (totalReviews > 0) {
                        Map<String, Object> result = new HashMap<>();
                        result.put("brewery", brewery.getName());
                        result.put("reviewCount", totalReviews);
                        result.put("country", brewery.getCountry());
                        result.put("mostReviewedStyle", mostReviewedStyle); //Set the most reviewed style
                        return result;
                    } else {
                        return null;
                    }
                })
                .filter(Objects::nonNull) // Remove breweries with 0 reviews
                .sorted(Comparator.comparingInt(b -> -((int) b.get("reviewCount")))) // Sort in descending order
                .limit(9)
                .collect(Collectors.toList());
    }


    /**
     * Fetches review trends by season.
     */
    public List<Map<String, Object>> getSeasonalReviewTrends() {
        List<Review> reviews = reviewRepository.findAll();
        List<Beer> beers = beerRepository.findAll();

        // Structure: Year -> Season -> Data
        Map<Integer, Map<String, Map<String, Object>>> yearlyData = new TreeMap<>(Collections.reverseOrder());

        for (Review review : reviews) {
            LocalDate reviewDate = review.getReviewDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            int reviewYear = reviewDate.getYear();

            // Adjust year for Winter (Jan & Feb go back one year)
            if (reviewDate.getMonth() == Month.JANUARY || reviewDate.getMonth() == Month.FEBRUARY) {
                reviewYear -= 1;
            }

            String season = getSeason(reviewDate);

            // Ensure year entry exists
            yearlyData.putIfAbsent(reviewYear, new HashMap<>());
            Map<String, Map<String, Object>> seasonData = yearlyData.get(reviewYear);
            seasonData.putIfAbsent(season, new HashMap<>());
            Map<String, Object> seasonInfo = seasonData.get(season);

            // Count total reviews for the season
            seasonInfo.put("reviewCount", (int) seasonInfo.getOrDefault("reviewCount", 0) + 1);
        }

        // Find the highest-rated, most-reviewed beers and most-reviewed style per season
        for (Beer beer : beers) {
            for (Review review : beer.getReviews()) {
                LocalDate reviewDate = review.getReviewDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                int year = reviewDate.getYear();

                // Adjust year for Winter (Jan & Feb go back one year)
                if (reviewDate.getMonth() == Month.JANUARY || reviewDate.getMonth() == Month.FEBRUARY) {
                    year -= 1;
                }

                String season = getSeason(reviewDate);

                if (yearlyData.containsKey(year) && yearlyData.get(year).containsKey(season)) {
                    Map<String, Object> seasonInfo = yearlyData.get(year).get(season);

                    // Track beer styles
                    Map<String, Integer> styleReviewCounts = (Map<String, Integer>) seasonInfo.getOrDefault("styleReviewCounts", new HashMap<>());
                    if (beer.getStyle() != null) {
                        String styleName = beer.getStyle().getStyle_name();
                        styleReviewCounts.put(styleName, styleReviewCounts.getOrDefault(styleName, 0) + 1);
                    }
                    seasonInfo.put("styleReviewCounts", styleReviewCounts);

                    // Update highest-rated beer
                    if (!seasonInfo.containsKey("highestRatedBeer") || beer.getAvgRating() > (double) seasonInfo.getOrDefault("highestRatedBeerRating", 0.0)) {
                        seasonInfo.put("highestRatedBeer", beer.getName());
                        seasonInfo.put("highestRatedBeerRating", Math.round(beer.getAvgRating() * 100.0) / 100.0);
                        seasonInfo.put("highestRatedBeerBrewery", beer.getBrewery().getName());
                    }

                    // Update most-reviewed beer
                    if (!seasonInfo.containsKey("mostReviewedBeer") || beer.getReviews().size() > (int) seasonInfo.getOrDefault("mostReviewedBeerCount", 0)) {
                        seasonInfo.put("mostReviewedBeer", beer.getName());
                        seasonInfo.put("mostReviewedBeerCount", beer.getReviews().size());
                    }
                }
            }
        }

        // Convert to List<Map<String, Object>> for PDF formatting
        List<Map<String, Object>> result = new ArrayList<>();
        for (var yearEntry : yearlyData.entrySet()) {
            int year = yearEntry.getKey();
            Map<String, Map<String, Object>> seasons = yearEntry.getValue();

            List<String> seasonOrder = Arrays.asList("Winter", "Autumn", "Summer", "Spring");

            seasons.entrySet().stream()
                    .sorted(Comparator.comparingInt(e -> seasonOrder.indexOf(e.getKey()))) // Enforce season order
                    .forEachOrdered(seasonEntry -> {
                        Map<String, Object> formattedEntry = new HashMap<>();
                        formattedEntry.put("year", year);
                        formattedEntry.put("season", seasonEntry.getKey());
                        formattedEntry.put("reviewCount", seasonEntry.getValue().get("reviewCount"));
                        formattedEntry.put("highestRatedBeer", seasonEntry.getValue().get("highestRatedBeer"));
                        formattedEntry.put("highestRatedBeerBrewery", seasonEntry.getValue().get("highestRatedBeerBrewery"));
                        formattedEntry.put("highestRatedBeerRating", seasonEntry.getValue().get("highestRatedBeerRating"));
                        formattedEntry.put("mostReviewedBeer", seasonEntry.getValue().get("mostReviewedBeer"));
                        formattedEntry.put("mostReviewedBeerCount", seasonEntry.getValue().get("mostReviewedBeerCount"));

                        // Determine the most reviewed style
                        Map<String, Integer> styleReviewCounts = (Map<String, Integer>) seasonEntry.getValue().get("styleReviewCounts");
                        if (styleReviewCounts != null) {
                            String mostReviewedStyle = styleReviewCounts.entrySet().stream()
                                    .max(Map.Entry.comparingByValue())
                                    .map(Map.Entry::getKey)
                                    .orElse("Not Set");
                            formattedEntry.put("mostReviewedStyle", mostReviewedStyle);
                        } else {
                            formattedEntry.put("mostReviewedStyle", "Not Set");
                        }

                        result.add(formattedEntry);
                    });

        }
        return result;
    }


    /**
     * Helper method to determine the season from a given month.
     */
    private String getSeason(LocalDate date) {
        Month month = date.getMonth();

        if (month == Month.DECEMBER || month == Month.JANUARY || month == Month.FEBRUARY) {
            return "Winter";  // Winter includes Dec (current year), Jan & Feb (same year)
        } else if (month == Month.MARCH || month == Month.APRIL || month == Month.MAY) {
            return "Spring";
        } else if (month == Month.JUNE || month == Month.JULY || month == Month.AUGUST) {
            return "Summer";
        } else {
            return "Autumn"; // September - November
        }
    }


    /**
     * Generates a Beer & Brewery Analytics PDF report.
     */
    public byte[] generateAnalyticsReport() {
        List<Map<String, Object>> topBeers = getTopRatedBeers();
        List<Map<String, Object>> topBreweries = getTopEngagedBreweries();
        List<Map<String, Object>> reviewTrends = getSeasonalReviewTrends();

        return pdfReportService.generateAnalyticsReport(topBeers, topBreweries, reviewTrends);
    }


    }
