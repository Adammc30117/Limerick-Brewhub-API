package src.application.controller;

import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import src.application.service.CustomerService;
import src.application.dto.CustomerSummaryDTO;
import src.application.service.BreweryService;
import src.application.service.PdfReportService;
import src.application.dto.BreweryReportDTO;

/**
 * CustomerBreweryController.java
 *
 * This controller handles API requests related to:
 * - Fetching customer summaries in JSON, XML, or TSV format.
 * - Generating PDF reports for breweries.
 *
 */
@RestController
@RequestMapping("/api")
@Tag(name = "Customer & Brewery API", description = "Endpoints for customer summaries and brewery reports")
public class CustomerBreweryController {

    private static final Logger logger = LoggerFactory.getLogger(CustomerBreweryController.class);

    private final CustomerService customerService;
    private final BreweryService breweryService;
    private final PdfReportService pdfReportService;
    private final ObjectMapper jsonMapper;
    private final XmlMapper xmlMapper;

    public CustomerBreweryController(CustomerService customerService, BreweryService breweryService, PdfReportService pdfReportService) {
        this.customerService = customerService;
        this.breweryService = breweryService;
        this.pdfReportService = pdfReportService;
        this.jsonMapper = new ObjectMapper();
        this.xmlMapper = new XmlMapper();
    }

    /**
     * Retrieves a summary for a specified customer.
     * Returns the summary in JSON, XML, or TSV format based on the Accept header.
     *
     * @param customerId    ID of the customer.
     * @param acceptHeader  Determines the response format.
     * @return ResponseEntity with customer summary in the requested format or 404 if customer not found.
     */
    @Operation(summary = "Get customer summary", description = "Fetches customer summary in JSON, XML, or TSV format.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Customer summary retrieved successfully"),
            @ApiResponse(responseCode = "404", description = "Customer not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping(value = "/customers/{customerId}/summary", produces = {
            MediaType.APPLICATION_JSON_VALUE,
            MediaType.APPLICATION_XML_VALUE,
            "text/tab-separated-values"
    })
    public ResponseEntity<String> getCustomerSummary(
            @PathVariable Long customerId,
            @RequestHeader(HttpHeaders.ACCEPT) String acceptHeader) {

        logger.info("Fetching summary for customer ID: {}", customerId);

        try {
            CustomerSummaryDTO summary = customerService.getCustomerSummary(customerId);

            if (summary == null) { // Ensure 404 Not Found response
                logger.warn("No summary found for customer ID: {}", customerId);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found");
            }

            if (MediaType.APPLICATION_XML_VALUE.equals(acceptHeader)) {
                return ResponseEntity.ok()
                        .contentType(MediaType.APPLICATION_XML)
                        .body(xmlMapper.writeValueAsString(summary));
            } else if ("text/tab-separated-values".equals(acceptHeader)) {
                return ResponseEntity.ok()
                        .contentType(MediaType.valueOf("text/tab-separated-values"))
                        .body(customerService.convertToTSV(summary));
            } else {
                return ResponseEntity.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(jsonMapper.writeValueAsString(summary));
            }

        } catch (RuntimeException e) {
            // Catch and return 404 if the customer is not found
            logger.warn("Customer not found: {}", customerId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Customer not found");

        } catch (Exception e) {
            // Handle any unexpected errors
            logger.error("Error processing customer summary request for ID: {}", customerId, e);
            return ResponseEntity.internalServerError().body("Error processing request: " + e.getMessage());
        }
    }


    /**
     * Generates a PDF report for a specified brewery.
     *
     * @param breweryId ID of the brewery.
     * @return ResponseEntity with the generated PDF file or 404 if brewery not found.
     */
    @Operation(summary = "Generate brewery report", description = "Generates a structured PDF report for a brewery.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "PDF report generated successfully"),
            @ApiResponse(responseCode = "404", description = "Brewery not found"),
            @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping(value = "/breweries/{breweryId}/report", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> generateBreweryReport(@PathVariable Long breweryId) {
        logger.info("Generating PDF report for brewery ID: {}", breweryId);

        try {
            BreweryReportDTO breweryReport = breweryService.getBreweryReport(breweryId);

            if (breweryReport == null) { // If service returns null, return 404
                logger.warn("No report available for brewery ID: {}", breweryId);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }

            byte[] pdfBytes = pdfReportService.generateBreweryReport(breweryReport);
            logger.info("Successfully generated PDF report for brewery ID: {}", breweryId);

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=brewery_report.pdf")
                    .contentType(MediaType.APPLICATION_PDF)
                    .body(pdfBytes);

        } catch (RuntimeException e) {
            // Catch and return 404 if the brewery doesn't exist
            logger.warn("Brewery not found: {}", breweryId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (Exception e) {
            // Catch unexpected errors and return 500
            logger.error("Error generating brewery report for ID: {}", breweryId, e);
            return ResponseEntity.internalServerError().body(null);
        }
    }
}
