package src.application.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import src.application.service.PasswordHashingService;

@RestController
@RequestMapping("/admin")
@Tag(name = "Admin Password Hashing", description = "Endpoint for hashing existing user passwords")
public class PasswordHashingController {

    private final PasswordHashingService passwordHashingService;

    public PasswordHashingController(PasswordHashingService passwordHashingService) {
        this.passwordHashingService = passwordHashingService;
    }

    /**
     * Hashes existing passwords for all users.
     *
     * @return A success message if hashing is completed.
     */
    @Operation(summary = "Hash existing passwords", description = "Applies password hashing to existing plaintext passwords.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Passwords hashed successfully"),
            @ApiResponse(responseCode = "403", description = "Forbidden - Admin access required"),
            @ApiResponse(responseCode = "500", description = "Error occurred while hashing passwords")
    })
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @GetMapping("/hash-passwords")
    public ResponseEntity<?> hashPasswords() {
        try {
            passwordHashingService.hashExistingPasswords();
            return ResponseEntity.ok("Passwords hashed successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error hashing passwords: " + e.getMessage());
        }
    }
}
