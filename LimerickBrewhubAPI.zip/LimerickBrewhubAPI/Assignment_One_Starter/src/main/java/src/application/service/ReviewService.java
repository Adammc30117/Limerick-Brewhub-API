package src.application.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import src.application.model.Beer;
import src.application.model.Review;
import src.application.model.User;
import src.application.repository.BeerRepository;
import src.application.repository.ReviewRepository;
import src.application.repository.CustomerRepository;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepository;

    @Autowired
    private BeerRepository beerRepository;

    @Autowired
    private CustomerRepository customerRepository;

    /**
     * Submits a new review for a beer. Ensures no duplicate reviews exist for the same user & beer.
     * Uses @Transactional to ensure atomicity.
     */
    @Transactional
    public Review submitReview(Long userId, Long beerId, int rating, String comment) {
        User user = customerRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Beer beer = beerRepository.findById(beerId)
                .orElseThrow(() -> new RuntimeException("Beer not found"));

        // Check if user has already reviewed this beer
        List<Review> existingReviews = reviewRepository.findByUserId(userId);
        Optional<Review> existingReview = existingReviews.stream()
                .filter(r -> r.getBeer().getId() == beerId)
                .findFirst();

        if (existingReview.isPresent()) {
            throw new RuntimeException("User has already reviewed this beer!");
        }

        // Create and save new review
        Review review = new Review();
        review.setUser(user);
        review.setBeer(beer);
        review.setRating(rating);
        review.setComment(comment);
        review.setReviewDate(new Date());

        Review savedReview = reviewRepository.save(review);

        // Recalculate beer's average rating
        recalculateBeerRating(beer);

        return savedReview;
    }

    /**
     * Updates an existing review and recalculates the beer's rating.
     */
    @Transactional
    public Review updateReview(Long reviewId, int newRating, String newComment) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Review not found"));

        review.setRating(newRating);
        review.setComment(newComment);
        review.setReviewDate(new Date());

        Review updatedReview = reviewRepository.save(review);

        // Recalculate beer rating
        recalculateBeerRating(review.getBeer());

        return updatedReview;
    }

    /**
     * Recalculates the average rating of a beer after a review is added or modified.
     */
    private void recalculateBeerRating(Beer beer) {
        List<Review> reviews = reviewRepository.findByBeerId(beer.getId());

        if (reviews.isEmpty()) {
            beer.setAvgRating(0.0); // Set avg rating to 0 if no reviews exist
        } else {
            double averageRating = reviews.stream()
                    .mapToInt(Review::getRating)
                    .average()
                    .orElse(0.0);
            beer.setAvgRating(averageRating);
        }

        beerRepository.save(beer);
    }

}
